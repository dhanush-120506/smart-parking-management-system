</main>
<footer class="text-center text-muted py-3 border-top">
  Smart Parking Management System &copy; <?= date('Y') ?> | CS23531 Web Programming
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="js/app.js"></script>
</body>
</html>
