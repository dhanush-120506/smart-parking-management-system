<?php
require_once __DIR__ . '/_init.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_out(['error' => 'POST required'], 405);

$in      = input();
$vehicle = strtoupper(trim($in['vehicle_no'] ?? ''));
$slotId  = (int)($in['slot_id'] ?? 0);   // 0 = auto-assign

if (!preg_match('/^[A-Z0-9 -]{4,15}$/', $vehicle)) {
    json_out(['error' => 'Enter a valid vehicle number (4-15 letters/digits)'], 422);
}

$pdo = db();
try {
    $pdo->beginTransaction();

    $chk = $pdo->prepare("SELECT id FROM bookings WHERE vehicle_no = ? AND status = 'ACTIVE'");
    $chk->execute([$vehicle]);
    if ($chk->fetch()) { $pdo->rollBack(); json_out(['error' => 'Vehicle is already parked'], 409); }

    if ($slotId > 0) {
        $q = $pdo->prepare("SELECT id, slot_number FROM slots WHERE id = ? AND status = 'FREE' FOR UPDATE");
        $q->execute([$slotId]);
    } else {
        $q = $pdo->query("SELECT id, slot_number FROM slots WHERE status = 'FREE' ORDER BY id LIMIT 1 FOR UPDATE");
    }
    $slot = $q->fetch();
    if (!$slot) { $pdo->rollBack(); json_out(['error' => 'No free slot available'], 409); }

    $pdo->prepare("INSERT INTO bookings (slot_id, vehicle_no, entry_time) VALUES (?, ?, ?)")
        ->execute([$slot['id'], $vehicle, date('Y-m-d H:i:s')]);
    $pdo->prepare("UPDATE slots SET status = 'OCCUPIED' WHERE id = ?")->execute([$slot['id']]);

    $pdo->commit();
    json_out(['message' => "Vehicle $vehicle parked in slot {$slot['slot_number']}", 'slot' => $slot['slot_number']]);
} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    json_out(['error' => 'Database error: ' . $e->getMessage()], 500);
}
