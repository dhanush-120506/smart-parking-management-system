<?php
require_once __DIR__ . '/_init.php';
try {
    $sql = "SELECT s.id, s.slot_number, s.slot_type, s.status,
                   b.vehicle_no, b.entry_time
            FROM slots s
            LEFT JOIN bookings b ON b.slot_id = s.id AND b.status = 'ACTIVE'
            ORDER BY s.id";
    json_out(db()->query($sql)->fetchAll());
} catch (Throwable $e) {
    json_out(['error' => 'Database error: ' . $e->getMessage()], 500);
}
