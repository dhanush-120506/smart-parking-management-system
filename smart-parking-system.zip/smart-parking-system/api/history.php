<?php
require_once __DIR__ . '/_init.php';
try {
    $sql = "SELECT b.id, s.slot_number, b.vehicle_no, b.entry_time, b.exit_time, b.fee, b.status
            FROM bookings b JOIN slots s ON s.id = b.slot_id
            ORDER BY b.id DESC LIMIT 100";
    json_out(db()->query($sql)->fetchAll());
} catch (Throwable $e) {
    json_out(['error' => 'Database error: ' . $e->getMessage()], 500);
}
