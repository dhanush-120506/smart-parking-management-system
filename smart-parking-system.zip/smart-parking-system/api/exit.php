<?php
require_once __DIR__ . '/_init.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_out(['error' => 'POST required'], 405);

$in      = input();
$vehicle = strtoupper(trim($in['vehicle_no'] ?? ''));
if ($vehicle === '') json_out(['error' => 'Vehicle number is required'], 422);

$pdo = db();
try {
    $pdo->beginTransaction();

    $q = $pdo->prepare("SELECT b.id, b.slot_id, b.entry_time, s.slot_number
                        FROM bookings b JOIN slots s ON s.id = b.slot_id
                        WHERE b.vehicle_no = ? AND b.status = 'ACTIVE' FOR UPDATE");
    $q->execute([$vehicle]);
    $b = $q->fetch();
    if (!$b) { $pdo->rollBack(); json_out(['error' => 'No active parking found for this vehicle'], 404); }

    $seconds = max(0, time() - strtotime($b['entry_time']));
    $hours   = max(1, (int)ceil($seconds / 3600));
    $fee     = $hours * RATE_PER_HOUR;

    $pdo->prepare("UPDATE bookings SET exit_time = ?, fee = ?, status = 'COMPLETED' WHERE id = ?")
        ->execute([date('Y-m-d H:i:s'), $fee, $b['id']]);
    $pdo->prepare("UPDATE slots SET status = 'FREE' WHERE id = ?")->execute([$b['slot_id']]);

    $pdo->commit();
    json_out([
        'message' => "Vehicle $vehicle left slot {$b['slot_number']}",
        'hours'   => $hours,
        'fee'     => $fee,
    ]);
} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    json_out(['error' => 'Database error: ' . $e->getMessage()], 500);
}
