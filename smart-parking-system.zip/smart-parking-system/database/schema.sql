CREATE DATABASE IF NOT EXISTS smart_parking;
USE smart_parking;

DROP TABLE IF EXISTS bookings;
DROP TABLE IF EXISTS slots;

CREATE TABLE slots (
  id INT AUTO_INCREMENT PRIMARY KEY,
  slot_number VARCHAR(10) NOT NULL UNIQUE,
  slot_type ENUM('CAR','BIKE','EV') NOT NULL DEFAULT 'CAR',
  status ENUM('FREE','OCCUPIED') NOT NULL DEFAULT 'FREE'
);

CREATE TABLE bookings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  slot_id INT NOT NULL,
  vehicle_no VARCHAR(15) NOT NULL,
  entry_time DATETIME NOT NULL,
  exit_time DATETIME NULL,
  fee DECIMAL(8,2) NULL,
  status ENUM('ACTIVE','COMPLETED') NOT NULL DEFAULT 'ACTIVE',
  FOREIGN KEY (slot_id) REFERENCES slots(id)
);

INSERT INTO slots (slot_number, slot_type) VALUES
('A1','CAR'),('A2','CAR'),('A3','CAR'),('A4','CAR'),('A5','CAR'),('A6','CAR'),
('B1','BIKE'),('B2','BIKE'),('B3','BIKE'),('B4','BIKE'),
('E1','EV'),('E2','EV');
