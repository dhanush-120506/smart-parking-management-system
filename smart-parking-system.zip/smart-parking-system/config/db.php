<?php
// Database settings (XAMPP defaults)
const DB_HOST = 'localhost';
const DB_NAME = 'smart_parking';
const DB_USER = 'root';
const DB_PASS = '';
const RATE_PER_HOUR = 20; // Rs. per hour (minimum 1 hour)

date_default_timezone_set('Asia/Kolkata');

function db(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $pdo = new PDO(
            "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
            DB_USER, DB_PASS,
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
             PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]
        );
    }
    return $pdo;
}

function json_out($data, int $code = 200): void {
    http_response_code($code);
    echo json_encode($data);
    exit;
}
