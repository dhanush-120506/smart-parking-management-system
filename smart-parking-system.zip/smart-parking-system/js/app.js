// Client-side logic: DOM, forms, events, fetch (Unit II)
const API = 'api/';
let slots = [];

const $ = (id) => document.getElementById(id);
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

function showAlert(msg, type = 'success') {
  const box = $('alertBox');
  if (!box) return;
  box.innerHTML = `<div class="alert alert-${type} alert-dismissible fade show">${esc(msg)}
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>`;
  setTimeout(() => (box.innerHTML = ''), 6000);
}

async function api(endpoint, body) {
  const opts = body ? { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) } : {};
  const res = await fetch(API + endpoint, opts);
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}

async function loadSlots() {
  try { slots = await api('slots.php'); render(); }
  catch (e) { showAlert(e.message, 'danger'); }
}

function render() {
  const type = $('filterType').value;
  const list = type ? slots.filter(s => s.slot_type === type) : slots;
  const free = slots.filter(s => s.status === 'FREE').length;

  $('statTotal').textContent = slots.length;
  $('statFree').textContent = free;
  $('statOcc').textContent = slots.length - free;

  $('slotGrid').innerHTML = list.map(s => `
    <div class="col-6 col-md-4 col-xl-3">
      <div class="slot-card ${s.status === 'FREE' ? 'slot-free' : 'slot-occupied'}">
        <div class="slot-no">${esc(s.slot_number)}</div>
        <div class="slot-type">${esc(s.slot_type)}</div>
        <div class="slot-info">${s.status === 'FREE' ? 'Available' : esc(s.vehicle_no)}</div>
      </div>
    </div>`).join('');

  const sel = $('parkSlot');
  const current = sel.value;
  sel.innerHTML = '<option value="0">Auto-assign</option>' +
    slots.filter(s => s.status === 'FREE')
         .map(s => `<option value="${s.id}">${esc(s.slot_number)} (${esc(s.slot_type)})</option>`).join('');
  sel.value = [...sel.options].some(o => o.value === current) ? current : '0';
}

document.addEventListener('DOMContentLoaded', () => {
  if (!$('slotGrid')) return; // not on dashboard page

  $('filterType').addEventListener('change', render);

  $('parkForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const vehicle = $('parkVehicle').value.trim();
    if (!vehicle) return showAlert('Vehicle number is required', 'warning');
    try {
      const r = await api('park.php', { vehicle_no: vehicle, slot_id: Number($('parkSlot').value) });
      showAlert(r.message);
      $('parkForm').reset();
      loadSlots();
    } catch (err) { showAlert(err.message, 'danger'); }
  });

  $('exitForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const vehicle = $('exitVehicle').value.trim();
    if (!vehicle) return showAlert('Vehicle number is required', 'warning');
    try {
      const r = await api('exit.php', { vehicle_no: vehicle });
      showAlert(`${r.message}. Duration billed: ${r.hours} hr. Fee: Rs. ${r.fee}`, 'info');
      $('exitForm').reset();
      loadSlots();
    } catch (err) { showAlert(err.message, 'danger'); }
  });

  loadSlots();
  setInterval(loadSlots, 10000); // auto-refresh
});
