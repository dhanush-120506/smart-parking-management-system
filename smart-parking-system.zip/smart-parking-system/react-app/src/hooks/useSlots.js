import { useCallback, useEffect, useState } from 'react';
import { getSlots } from '../api.js';

export default function useSlots(refreshMs = 10000) {
  const [slots, setSlots] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const refresh = useCallback(async () => {
    try {
      setSlots(await getSlots());
      setError('');
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refresh();
    const id = setInterval(refresh, refreshMs);
    return () => clearInterval(id); // cleanup (component life cycle)
  }, [refresh, refreshMs]);

  return { slots, loading, error, refresh };
}
