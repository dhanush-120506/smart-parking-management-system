import { useState } from 'react';
import PropTypes from 'prop-types';
import { parkVehicle } from '../api.js';

export default function ParkForm({ freeSlots, onDone, onMessage }) {
  const [vehicle, setVehicle] = useState('');
  const [slotId, setSlotId] = useState(0);

  const submit = async (e) => {
    e.preventDefault();
    if (!vehicle.trim()) return onMessage('Vehicle number is required', 'warning');
    try {
      const r = await parkVehicle(vehicle.trim(), Number(slotId));
      onMessage(r.message, 'success');
      setVehicle('');
      setSlotId(0);
      onDone();
    } catch (err) {
      onMessage(err.message, 'danger');
    }
  };

  return (
    <div className="card shadow-sm mb-4">
      <div className="card-header bg-primary text-white">Park a Vehicle</div>
      <form className="card-body" onSubmit={submit}>
        <label className="form-label">Vehicle Number</label>
        <input className="form-control mb-3" placeholder="TN01AB1234" value={vehicle} onChange={(e) => setVehicle(e.target.value)} />
        <label className="form-label">Slot</label>
        <select className="form-select mb-3" value={slotId} onChange={(e) => setSlotId(e.target.value)}>
          <option value={0}>Auto-assign</option>
          {freeSlots.map((s) => (
            <option key={s.id} value={s.id}>{s.slot_number} ({s.slot_type})</option>
          ))}
        </select>
        <button className="btn btn-primary w-100">Park</button>
      </form>
    </div>
  );
}

ParkForm.propTypes = {
  freeSlots: PropTypes.array.isRequired,
  onDone: PropTypes.func.isRequired,
  onMessage: PropTypes.func.isRequired,
};
