import { useState } from 'react';
import PropTypes from 'prop-types';
import { exitVehicle } from '../api.js';

export default function ExitForm({ onDone, onMessage }) {
  const [vehicle, setVehicle] = useState('');

  const submit = async (e) => {
    e.preventDefault();
    if (!vehicle.trim()) return onMessage('Vehicle number is required', 'warning');
    try {
      const r = await exitVehicle(vehicle.trim());
      onMessage(`${r.message}. Duration billed: ${r.hours} hr. Fee: Rs. ${r.fee}`, 'info');
      setVehicle('');
      onDone();
    } catch (err) {
      onMessage(err.message, 'danger');
    }
  };

  return (
    <div className="card shadow-sm">
      <div className="card-header bg-warning">Exit &amp; Pay</div>
      <form className="card-body" onSubmit={submit}>
        <label className="form-label">Vehicle Number</label>
        <input className="form-control mb-3" value={vehicle} onChange={(e) => setVehicle(e.target.value)} />
        <button className="btn btn-warning w-100">Calculate Fee &amp; Exit</button>
      </form>
    </div>
  );
}

ExitForm.propTypes = { onDone: PropTypes.func.isRequired, onMessage: PropTypes.func.isRequired };
