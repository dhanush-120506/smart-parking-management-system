import PropTypes from 'prop-types';

// Props + prop validation (Unit IV/V)
export default function SlotCard({ slotNumber, slotType, status, vehicleNo }) {
  const free = status === 'FREE';
  return (
    <div className={`slot-card ${free ? 'slot-free' : 'slot-occupied'}`}>
      <div className="slot-no">{slotNumber}</div>
      <div className="slot-type">{slotType}</div>
      <div className="small">{free ? 'Available' : vehicleNo}</div>
    </div>
  );
}

SlotCard.propTypes = {
  slotNumber: PropTypes.string.isRequired,
  slotType: PropTypes.oneOf(['CAR', 'BIKE', 'EV']).isRequired,
  status: PropTypes.oneOf(['FREE', 'OCCUPIED']).isRequired,
  vehicleNo: PropTypes.string,
};

SlotCard.defaultProps = { vehicleNo: '' };
