import PropTypes from 'prop-types';

export default function Stats({ total, free }) {
  const items = [
    { label: 'Total Slots', value: total, cls: '' },
    { label: 'Free', value: free, cls: 'text-success' },
    { label: 'Occupied', value: total - free, cls: 'text-danger' },
  ];
  return (
    <div className="row text-center mb-4">
      {items.map((i) => (
        <div className="col-4" key={i.label}>
          <div className="card shadow-sm"><div className="card-body">
            <h2 className={i.cls}>{i.value}</h2><small>{i.label}</small>
          </div></div>
        </div>
      ))}
    </div>
  );
}

Stats.propTypes = { total: PropTypes.number.isRequired, free: PropTypes.number.isRequired };
