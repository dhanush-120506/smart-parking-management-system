import { useState } from 'react';
import PropTypes from 'prop-types';
import SlotCard from './SlotCard.jsx';

export default function SlotGrid({ slots }) {
  const [type, setType] = useState('');
  const list = type ? slots.filter((s) => s.slot_type === type) : slots;

  return (
    <>
      <div className="d-flex justify-content-between mb-2">
        <h5>Parking Slots</h5>
        <select className="form-select form-select-sm w-auto" value={type} onChange={(e) => setType(e.target.value)}>
          <option value="">All types</option>
          <option>CAR</option>
          <option>BIKE</option>
          <option>EV</option>
        </select>
      </div>
      <div className="row g-3">
        {list.map((s) => (
          <div className="col-6 col-md-4 col-xl-3" key={s.id}>
            <SlotCard slotNumber={s.slot_number} slotType={s.slot_type} status={s.status} vehicleNo={s.vehicle_no || ''} />
          </div>
        ))}
      </div>
    </>
  );
}

SlotGrid.propTypes = { slots: PropTypes.array.isRequired };
