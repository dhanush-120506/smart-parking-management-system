import { useState } from 'react';
import useSlots from '../hooks/useSlots.js';
import Stats from '../components/Stats.jsx';
import SlotGrid from '../components/SlotGrid.jsx';
import ParkForm from '../components/ParkForm.jsx';
import ExitForm from '../components/ExitForm.jsx';

export default function Dashboard() {
  const { slots, loading, error, refresh } = useSlots();
  const [msg, setMsg] = useState(null); // { text, type }

  const notify = (text, type = 'success') => {
    setMsg({ text, type });
    setTimeout(() => setMsg(null), 6000);
  };

  const freeSlots = slots.filter((s) => s.status === 'FREE');

  return (
    <>
      {msg && <div className={`alert alert-${msg.type}`}>{msg.text}</div>}
      {error && <div className="alert alert-danger">{error}</div>}
      <Stats total={slots.length} free={freeSlots.length} />
      <div className="row g-4">
        <div className="col-lg-4">
          <ParkForm freeSlots={freeSlots} onDone={refresh} onMessage={notify} />
          <ExitForm onDone={refresh} onMessage={notify} />
        </div>
        <div className="col-lg-8">
          {loading ? <p>Loading slots...</p> : <SlotGrid slots={slots} />}
        </div>
      </div>
    </>
  );
}
