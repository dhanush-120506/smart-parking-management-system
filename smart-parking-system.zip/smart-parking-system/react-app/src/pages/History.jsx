import { useEffect, useState } from 'react';
import { getHistory } from '../api.js';

export default function History() {
  const [rows, setRows] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    getHistory().then(setRows).catch((e) => setError(e.message));
  }, []);

  const total = rows.reduce((sum, r) => sum + Number(r.fee || 0), 0);

  return (
    <>
      <h4>Parking History</h4>
      {error && <div className="alert alert-danger">{error}</div>}
      <p className="text-muted">Total collection: <strong>Rs. {total.toFixed(2)}</strong></p>
      <div className="table-responsive">
        <table className="table table-striped align-middle">
          <thead className="table-dark">
            <tr><th>#</th><th>Slot</th><th>Vehicle</th><th>Entry</th><th>Exit</th><th>Fee</th><th>Status</th></tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.id}>
                <td>{r.id}</td><td>{r.slot_number}</td><td>{r.vehicle_no}</td>
                <td>{r.entry_time}</td><td>{r.exit_time || '-'}</td>
                <td>{r.fee ?? '-'}</td>
                <td><span className={`badge bg-${r.status === 'ACTIVE' ? 'danger' : 'success'}`}>{r.status}</span></td>
              </tr>
            ))}
            {rows.length === 0 && <tr><td colSpan="7" className="text-center">No records yet</td></tr>}
          </tbody>
        </table>
      </div>
    </>
  );
}
