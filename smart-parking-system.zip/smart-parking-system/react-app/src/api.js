const BASE = import.meta.env.VITE_API_URL || 'http://localhost/smart-parking-system/api';

async function request(endpoint, body) {
  const options = body
    ? { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }
    : {};
  const res = await fetch(`${BASE}/${endpoint}`, options);
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}

export const getSlots = () => request('slots.php');
export const getHistory = () => request('history.php');
export const parkVehicle = (vehicle_no, slot_id = 0) => request('park.php', { vehicle_no, slot_id });
export const exitVehicle = (vehicle_no) => request('exit.php', { vehicle_no });
