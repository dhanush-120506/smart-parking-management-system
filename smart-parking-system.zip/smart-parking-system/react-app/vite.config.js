import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  // For deployment under XAMPP htdocs: base: '/smart-parking-system/react-app/dist/'
});
